package com.mycompany.main;

import java.util.ArrayList;
import java.util.Scanner;

public class CoffeeMachine {
    private ArrayList<Flavor> sabores;
    private double[] precos; // Nossa "coluna" de preços
    private Scanner scanner;

    public CoffeeMachine() {
        scanner = new Scanner(System.in);
        sabores = new ArrayList<>();
        
        // Cadastrando os preços equivalentes a cada sabor
        precos = new double[]{4.50, 5.00, 6.00, 6.50, 8.00, 7.50};

        // Cadastrando os sabores no "banco" da máquina
        sabores.add(new Flavor("Cafe Tradicional", 30));
        sabores.add(new Flavor("Cafe com Leite", 30));
        sabores.add(new Flavor("Capuccino", 30));
        sabores.add(new Flavor("Chocolate Quente", 30));
        
        // Esses dois começam com 2 doses para a LUZ AMARELA ficar acesa
        sabores.add(new Flavor("Mocha", 2));       
        sabores.add(new Flavor("Cafe Gelado", 2)); 
    }

    public void iniciar() {
        int opcao;

        do {
            exibirMenu();
            opcao = lerInteiro("Escolha uma opcao: ");

            switch (opcao) {
                case 1:
                    comprarBebida();
                    break;
                case 2:
                    mostrarEstoque();
                    break;
                case 0:
                    System.out.println("Encerrando o sistema da maquina de cafe...");
                    break;
                default:
                    System.out.println("Opcao invalida.");
            }

        } while (opcao != 0);
    }

    private void exibirMenu() {
        System.out.println("\n==============================");
        System.out.println("     MAQUINA DE CAFE");
        System.out.println("==============================");
        System.out.println("1 - Comprar bebida");
        System.out.println("2 - Ver estoque");
        System.out.println("0 - Sair");
        System.out.println("==============================");
    }

    private void comprarBebida() {
        System.out.println("\n------ SABORES DISPONIVEIS ------");
        for (int i = 0; i < sabores.size(); i++) {
            Flavor sabor = sabores.get(i);
            System.out.printf("%d - %s | Preco: R$ %.2f | Doses: %d\n", 
                              (i + 1), sabor.getNome(), precos[i], sabor.getDoses());
        }

        int escolha = lerInteiro("Escolha o sabor desejado: ");

        if (escolha < 1 || escolha > sabores.size()) {
            System.out.println("Erro: Sabor invalido.");
            return;
        }

        Flavor saborEscolhido = sabores.get(escolha - 1);
        double precoProduto = precos[escolha - 1];

        if (!saborEscolhido.estaDisponivel()) {
            System.out.println("LUZ VERMELHA ACESA - " + saborEscolhido.getNome() + " esgotado.");
            System.out.println("Nao e possivel servir esta bebida.");
            return;
        }

        System.out.println("Voce escolheu: " + saborEscolhido.getNome());
        System.out.printf("Valor a pagar: R$ %.2f\n", precoProduto);

        Payment pagamento = processarPagamento();

        if (pagamento == null) {
            return;
        }

        // TRATAMENTO DE ERRO: Saldo inválido
        if (pagamento.getSaldo() < precoProduto) {
            System.out.println("Erro: saldo invalido. Valor insulficiente para a compra.");
            return;
        }

        if (!pagamento.isPagamentoAprovado()) {
            System.out.println("Erro: Pagamento nao aprovado pela operadora. Tente novamente.");
            return;
        }

        servirCafe(saborEscolhido);
    }

    private Payment processarPagamento() {
        System.out.println("\n------ PAGAMENTO ------");
        System.out.println("1 - Cartao");
        System.out.println("2 - Pix");

        int tipoPagamento = lerInteiro("Escolha a forma de pagamento: ");
        String tipo;

        switch (tipoPagamento) {
            case 1:
                tipo = "Cartao";
                break;
            case 2:
                tipo = "Pix";
                break;
            default:
                System.out.println("Forma de pagamento invalida.");
                return null;
        }

        double saldo = lerDouble("Informe o seu saldo disponivel na conta: R$ ");

        System.out.println("Simular aprovacao do pagamento?");
        System.out.println("1 - Aprovar (Sim)");
        System.out.println("2 - Recusar (Nao)");
        int aprovado = lerInteiro("Escolha: ");

        boolean pagamentoAprovado = aprovado == 1;

        return new Payment(tipo, saldo, pagamentoAprovado);
    }

    private void servirCafe(Flavor sabor) {
        sabor.retirarDose(); // "UPDATE" diminuindo a dose

        System.out.println("\nPreparando " + sabor.getNome() + "...");
        System.out.println("Bebida servida com sucesso!");
        verificarNivel(sabor);
    }

    private void verificarNivel(Flavor sabor) {
        if (sabor.acabou()) {
            System.out.println("LUZ VERMELHA ACESA - Estoque de " + sabor.getNome() + " acabou totalmente.");
        } else if (sabor.nivelBaixo()) {
            System.out.println("LUZ AMARELA ACESA - Estoque de " + sabor.getNome() + " em nivel baixo.");
        } else {
            System.out.println("LUZ VERDE ACESA - Estoque de " + sabor.getNome() + " em nivel normal.");
        }
    }

    private void mostrarEstoque() {
        System.out.println("\n------ ESTOQUE ATUAL ------");
        for (Flavor sabor : sabores) {
            System.out.print(sabor.getNome() + " - " + sabor.getDoses() + " doses");

            if (sabor.acabou()) {
                System.out.print(" | LUZ VERMELHA");
            } else if (sabor.nivelBaixo()) {
                System.out.print(" | LUZ AMARELA");
            } else {
                System.out.print(" | LUZ VERDE");
            }

            System.out.println();
        }
    }

    private int lerInteiro(String mensagem) {
        while (true) {
            try {
                System.out.print(mensagem);
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Erro de entrada: Digite apenas numeros inteiros.");
            }
        }
    }

    private double lerDouble(String mensagem) {
        while (true) {
            try {
                System.out.print(mensagem);
                return Double.parseDouble(scanner.nextLine().replace(",", "."));
            } catch (NumberFormatException e) {
                System.out.println("Erro de entrada: Digite um valor monetario valido (ex: 5.50).");
            }
        }
    }
}