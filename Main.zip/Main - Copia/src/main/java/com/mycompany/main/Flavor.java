package com.mycompany.main;

public class Flavor {
    private String nome;
    private int doses;

    public Flavor(String nome, int doses) {
        this.nome = nome;
        this.doses = doses;
    }

    public String getNome() {
        return nome;
    }

    public int getDoses() {
        return doses;
    }

    public void retirarDose() {
        if (doses > 0) {
            doses--;
        }
    }

    public boolean estaDisponivel() {
        return doses > 0;
    }

    // Ajustado para acender a luz amarela com 2 ou 1 dose restante
    public boolean nivelBaixo() {
        return doses <= 2 && doses > 0;
    }

    public boolean acabou() {
        return doses == 0;
    }
}