package com.mycompany.main;

public class Main {
    public static void main(String[] args) {
        CoffeeMachine maquina = new CoffeeMachine();
        maquina.iniciar();
    }
}