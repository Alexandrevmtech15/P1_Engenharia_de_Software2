package com.mycompany.main;

public class Payment {
    private String tipo;
    private double saldo;
    private boolean pagamentoAprovado;

    public Payment(String tipo, double saldo, boolean pagamentoAprovado) {
        this.tipo = tipo;
        this.saldo = saldo;
        this.pagamentoAprovado = pagamentoAprovado;
    }

    public String getTipo() {
        return tipo;
    }

    public double getSaldo() {
        return saldo;
    }

    public boolean isPagamentoAprovado() {
        return pagamentoAprovado;
    }
}